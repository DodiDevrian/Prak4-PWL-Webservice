<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get( uri: '/proyek', action: [App\Http\Controllers\ProyekController::class, 'index']);
Route::get( uri: '/proyek/{id}', action: [App\Http\Controllers\ProyekController::class, 'detail']);
Route::post( uri: '/proyek/{id}/komen', action: [App\Http\Controllers\ProyekController::class, 'simpan']);
Route::get( uri: '/getkomen/{id}', action: [App\Http\Controllers\ProyekController::class, 'datakomen']);