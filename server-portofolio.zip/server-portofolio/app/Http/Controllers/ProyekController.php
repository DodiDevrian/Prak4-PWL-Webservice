<?php

namespace App\Http\Controllers;
use App\Models\Proyek;
use App\Http\Resources\ProyekResource;
use App\Models\Komen;
use App\Http\Resources\KomenResource;
use Illuminate\Http\Request;

class ProyekController extends Controller
{
    public function index(){

        return ProyekResource::collection( resource: Proyek::all()); 
    }
    
    public function detail($id){
        return ProyekResource::collection( resource: Proyek::query()->where('id', $id)->get()); 
    }

    public function datakomen($id){
        return KomenResource::collection( resource: Komen::query()->where('proyek_id', $id)->get()); 
    }
    
    public function simpan(Request $request)
    {
        $request->validate([
            'nama'=>'required',
            'isi_komentar'=>'required',
        ]);

        try{
            Komen::create($request->post());
            return response()->json([
                'message'=>'Sukses!!'
            ]);
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return response()->json([
                'message'=>'Error!!'
            ],500);
        }
    }
}