<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProyekResource extends JsonResource
{
 
    public function toArray($request)
    {
        return [
            'id'=> $this->id,
            'nama'=> $this->nama,
            'deskripsi' => $this->deskripsi,
            'image'=> $this->image
        ];
    }
}