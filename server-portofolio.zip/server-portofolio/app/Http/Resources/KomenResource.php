<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class KomenResource extends JsonResource
{
 
    public function toArray($request)
    {
        return [
            'id'=> $this->id,
            'nama'=> $this->nama,
            'isi_komentar'=> $this->isi_komentar,
            'proyek_id' =>$this->proyek_id,
            'created_at' =>$this->created_at->format('Y-m-d H:i:s')
        ];
    }
}