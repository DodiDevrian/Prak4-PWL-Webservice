<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Proyek;

class ProyekSeeder extends Seeder
{
   
    public function run()
    {
        $list_proyek = [[
            'nama' => 'Aplikasi Gojek',
            'deskripsi' => 'Aplikasi ini berguna untuk memudahkan kita untuk memesan ojek secara online dengan menentukan lokasi yang ingin dikunjungi dan biaya yang sepadan telah ditentukan.',
            'image' => 'https://cdn.techinasia.com/wp-content/uploads/2019/07/Untitled.png'
        ],
        [
            'nama' => 'Aplikasi Grab',
            'deskripsi' => ' Grab adalah Perusahaan teknologi asal Malaysia yang berkantor di Singapura yang menyediakan aplikasi layanan transportasi angkutan umum meliputi kendaraan bermotor roda 2 maupun roda 4,',
            'image' => 'https://assets.grab.com/wp-content/uploads/sites/4/2021/04/15151634/Grab_Logo_2021.jpg'
        ],
        [
            'nama' => 'Aplikasi Shopee',
            'deskripsi' =>  'Shopee adalah aplikasi Marketplace online untuk jual beli di ponsel dengan mudah dan cepat.',
            'image' => 'https://1000logos.net/wp-content/uploads/2021/02/Shopee-Logo-2015.png'
        ],
        [
            'nama' => 'Aplikasi Tokopedia',
            'deskripsi' => 'Aplikasi Tokopedia adalah platform jual-beli digital yang biasa kita sebut sebagai toko online.',
            'image' => 'https://blue.kumparan.com/image/upload/fl_progressive,fl_lossy,c_fill,q_auto:best,w_640/v1598609040/fqma8jkwgzlx4ruwdu2n.jpg'
        ]
    ];

    
        foreach ($list_proyek as $proyek){
            Proyek::create($proyek);
        };
    }
}